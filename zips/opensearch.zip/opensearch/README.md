# opensearch

OCI Search Service with OpenSearch を扱うための最低限の環境が作成されます．

## magic link

[deploy your tenancy](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/shukawam/resource-manager/raw/main/opensearch/zips/opensearch.zip)

## ovewview

- Network
- OpenSearch - Cluster
  - Master/Data/Dashboard Node
- Compute for OpenSearch Bastion
