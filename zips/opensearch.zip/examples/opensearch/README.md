# opensearch

OCI Search Service with OpenSearch を扱うための最低限の環境が作成されます．

## Magic Button

[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/shukawam/resource-manager/raw/main/zips/opensearch.zip)

## ovewview

- Network
- OpenSearch - Cluster
  - Master/Data/Dashboard Node
- Compute for OpenSearch Bastion
